package elso;

public class SajatException1 extends IllegalArgumentException{
    public SajatException1() {
        super();
    }

    public SajatException1(String uzi) {
        super(uzi);
    }
}
