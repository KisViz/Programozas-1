package elso;

public interface KozosResz1 {
    void penztKolt(int mennyit);
    int getPenz();
}
