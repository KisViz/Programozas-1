public class Teherkivetel extends RuntimeException{
    Teherkivetel (String szoveg){
        super(szoveg);
    }
}
