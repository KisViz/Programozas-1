public interface Teherinterface {
    public void kilometertTesz (int mennyit);

    public int getKilometer();
}
