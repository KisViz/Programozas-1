public class SajatException extends IllegalArgumentException{
    public SajatException() {
        super();
    }

    public SajatException(String uzi) {
        super(uzi);
    }
}
