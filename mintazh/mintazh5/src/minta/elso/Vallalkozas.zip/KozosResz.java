public interface KozosResz {
    void penztKolt(int mennyit);
    int getPenz();
}
