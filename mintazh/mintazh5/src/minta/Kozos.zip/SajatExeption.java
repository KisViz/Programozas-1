public class SajatExeption extends IllegalArgumentException{
    public SajatExeption(String s) {
        super(s);
    }

    public SajatExeption() {
    }
}
