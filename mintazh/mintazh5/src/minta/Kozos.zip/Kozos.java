public interface Kozos {
    void penztKolt(int mennyit);
    int getPenz();
}
