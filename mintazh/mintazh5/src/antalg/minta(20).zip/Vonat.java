
import java.util.*;;

public class Vonat {
    private Map<String, Integer> utasok = new HashMap<>();

    public int getTomeg() {
        return this.utasok.size() * 75;
    }

    public void rakomanytHozzaad(String utas) {
        if (getTomeg() >= 100) {
            throw new RuntimeException("Nincs eleg hely!");
        }
        this.utasok.put(utas, 0);
    }
}
