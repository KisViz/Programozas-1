public interface Namer {
    void rename(FileSystemEntry adat);
}
