public interface BesorolassalRendelkezo {
    int getKorhatarBesorolas();
}
